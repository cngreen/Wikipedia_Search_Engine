import sys
import os
import math

wordDict = {}
#out_file = open('total_document_count.txt', "r")
#total_num_docs = int(out_file.readline())

total_num_docs = 10

for line in sys.stdin:
    line = line.rstrip('\n')
    word = line.split("\t")[0]
    line2 = line.split("\t")[1]
    docsArray = line2.split(" ")

    newDocs = [] # will have doc id, num occur, freq, normalization factor

    size = len(docsArray)

    i = 1

    total_num_of_occurrences = 0

    while (i < size):
        total_num_of_occurrences += int(docsArray[i])
        i += 3

    num_of_docs_with_term = size / 3

    idf = math.log10(total_num_docs/num_of_docs_with_term)

    i = 0
    while (i < size):
        newDocs.append(docsArray[i]) #doc_id
        i += 1
        newDocs.append(docsArray[i]) #num_occur
        i += 1
        newDocs.append(docsArray[i]) #freq
        freq = float(docsArray[i])
        normalization_factor = (pow(idf, 2) * pow(freq, 2))
        i += 1
        newDocs.append(normalization_factor)

    newDocsString = ''
    for x in newDocs:
        newDocsString += (str(x) + ' ')
    
    wordDict[word] = [idf, total_num_of_occurrences, newDocsString]

for word in wordDict:
    print (word, sep = '', end='\t'),
    print (str(wordDict[word][0]), sep= '', end=' '),
    print (str(wordDict[word][1]), sep= '', end=' '),
    print (wordDict[word][2], sep= '')